<?php
function create_invention_posttype() {

    register_post_type( 'Inventions',
    // CPT Options
        array(
            'labels' => array(
                'name' => __( 'Inventions' ),
                'singular_name' => __( 'Invention' )
            ),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'Inventions'),
            'show_in_rest' => true,

        )
    );
}

add_action( 'init', 'create_invention_posttype' );

function custom_post_type2() {


    $labels = array(
        'name'                => _x( 'Inventions', 'Post Type General Name', 'twentytwenty' ),
        'singular_name'       => _x( 'Invention', 'Post Type Singular Name', 'twentytwenty' ),
        'menu_name'           => __( 'Inventions', 'twentytwenty' ),
        'parent_item_colon'   => __( 'Parent Invention', 'twentytwenty' ),
        'all_items'           => __( 'All Inventions', 'twentytwenty' ),
        'view_item'           => __( 'View Invention', 'twentytwenty' ),
        'add_new_item'        => __( 'Add New Invention', 'twentytwenty' ),
        'add_new'             => __( 'Add New', 'twentytwenty' ),
        'edit_item'           => __( 'Edit Invention', 'twentytwenty' ),
        'update_item'         => __( 'Update Invention', 'twentytwenty' ),
        'search_items'        => __( 'Search Invention', 'twentytwenty' ),
        'not_found'           => __( 'Not Found', 'twentytwenty' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'twentytwenty' ),
    );



    $args = array(
        'label'               => __( 'Inventions', 'twentytwenty' ),
        'description'         => __( 'Invention news and reviews', 'twentytwenty' ),
        'labels'              => $labels,

        'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields', ),

        'taxonomies'          => array( 'genres' ),

        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'menu_icon'           => 'http://www.example.com/wp-content/uploads/2014/11/your-cpt-icon.png',
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'post',
        'show_in_rest' => true,

    );


    register_post_type( 'Inventions', $args );

}


add_action( 'init', 'custom_post_type2', 0 );

add_action( 'pre_get_posts', 'add_my_post_types_to_query' );

function add_my_post_types_to_query2( $query ) {
    if ( is_home() && $query->is_main_query() )
        $query->set( 'post_type', array( 'post', 'Inventions' ) );
    return $query;
}
