<?php
/*
Plugin Name: Ideas & Inventions | Custom Post Types
Plugin URI: http://jkaraffa1.bitlampsites.com
Description: Adds custom posty types for both Inventions and Ideas
Author: Jake Karaffa
Version: 1.0.0
License: GPL2
*/


include dirname( __FILE__ ) .'/ideas.php';
include dirname( __FILE__ ) .'/inventions.php';
